/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ico.fes.factory;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Prueba {
    public static void main(String[] args) {
          Scanner teclado = new Scanner(System.in);
        int eleccion = 0;
        
        System.out.println("¿Que dispositivo quieres?");
        System.out.println(InterA.CO_ASUS +" Computadora asus");
        System.out.println(InterA.CO_GIGABYTE +" Computadora gigabyte");
        System.out.println(InterA.SM_XIAOMI +" Smartphone xiaomi");
        System.out.println(InterA.SM_SAMSUMG +" Smartphone samsumg");
        System.out.println(InterA.TA_SAMSUMG +" Tablet samsumg");
        System.out.println(InterA.TA_APPLE +" Tablet apple");
        
        try {
            System.out.print("Elige el numero:");
            eleccion = teclado.nextInt();
        } catch (Exception e) {
            System.out.println("No capturaste el numero");
        }
        
        InterA dispo = Factory.createInterA(eleccion);
        System.out.println(dispo.toString());
    }
}
