/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ico.fes.factory;

import fes.art.Computadora;
import fes.art.Smartphone;
import fes.art.Tablet;

/**
 *
 * @author Admin
 */
public class Factory {
     public static InterA createInterA(int tipo){
        switch (tipo) {
            case InterA.CO_ASUS:
                    return new Computadora("ASUS",false,true);
            case InterA.CO_GIGABYTE:
                    return new Computadora("GIGABYTE",true, false);
            case InterA.SM_XIAOMI:
                    return  new Smartphone("XIAOMI",true, false, true);
            case InterA.SM_SAMSUMG:
                    return new Smartphone("SAMSUMG",true, true, false);
            case InterA.TA_SAMSUMG:
                    return new Tablet("SAMSUMG",true, true, true);
            case InterA.TA_APPLE:
                    return  new Tablet("APPLE",false, true, true);
                
                    
                    
                    
            default:
                throw new AssertionError();
        }
    }
}
