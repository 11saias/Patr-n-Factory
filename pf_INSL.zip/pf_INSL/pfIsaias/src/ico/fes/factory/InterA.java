/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ico.fes.factory;

/**
 *
 * @author Admin
 */
public interface InterA {
    public static final int CO_ASUS = 1;
    public static final int CO_GIGABYTE = 2;
    public static final int SM_XIAOMI = 3;
    public static final int SM_SAMSUMG = 4;
    public static final int TA_SAMSUMG = 5;
    public static final int TA_APPLE = 6;
    //etc con lo demas
}
