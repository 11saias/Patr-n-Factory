/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fes.art;

import ico.fes.factory.InterA;

/**
 *
 * @author Admin
 */
public class Computadora implements InterA{
    String marca;
    
    boolean precio;
    boolean peso;

    public Computadora() {
    }

    public Computadora(String marca, boolean precio, boolean peso) {
        this.marca = marca;
        this.precio = precio;
        this.peso = peso;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isPrecio() {
        return precio;
    }

    public void setPrecio(boolean precio) {
        this.precio = precio;
    }

    public boolean isPeso() {
        return peso;
    }

    public void setPeso(boolean peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Computadora{" + "marca=" + marca + ", precio=" + precio + ", peso=" + peso + '}';
    }
    
    
}


