/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fes.art;

import ico.fes.factory.InterA;

/**
 *
 * @author Admin
 */
public class Smartphone implements InterA {
    String nMarca;
    
    boolean color;
    boolean pantalla;
    boolean peso;

    public Smartphone() {
    }

    public Smartphone(String nMarca, boolean color, boolean pantalla, boolean peso) {
        this.nMarca = nMarca;
        this.color = color;
        this.pantalla = pantalla;
        this.peso = peso;
    }

    public String getnMarca() {
        return nMarca;
    }

    public void setnMarca(String nMarca) {
        this.nMarca = nMarca;
    }

    public boolean isColor() {
        return color;
    }

    public void setColor(boolean color) {
        this.color = color;
    }

    public boolean isPantalla() {
        return pantalla;
    }

    public void setPantalla(boolean pantalla) {
        this.pantalla = pantalla;
    }

    public boolean isPeso() {
        return peso;
    }

    public void setPeso(boolean peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Smartphone{" + "nMarca=" + nMarca + ", color=" + color + ", pantalla=" + pantalla + ", peso=" + peso + '}';
    }
    
    
}
