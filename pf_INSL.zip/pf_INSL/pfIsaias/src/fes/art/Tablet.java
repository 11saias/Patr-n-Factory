/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fes.art;

import ico.fes.factory.InterA;

/**
 *
 * @author Admin
 */
public class Tablet implements InterA {
    String marca;
    
    boolean color;
    boolean pantalla;
    boolean peso;

    public Tablet() {
    }

    public Tablet(String marca, boolean color, boolean pantalla, boolean peso) {
        this.marca = marca;
        this.color = color;
        this.pantalla = pantalla;
        this.peso = peso;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isColor() {
        return color;
    }

    public void setColor(boolean color) {
        this.color = color;
    }

    public boolean isPantalla() {
        return pantalla;
    }

    public void setPantalla(boolean pantalla) {
        this.pantalla = pantalla;
    }

    public boolean isPeso() {
        return peso;
    }

    public void setPeso(boolean peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Tablet{" + "marca=" + marca + ", color=" + color + ", pantalla=" + pantalla + ", peso=" + peso + '}';
    }
    
    
}
